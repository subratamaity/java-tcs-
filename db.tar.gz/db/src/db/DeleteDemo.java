package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ilp.helper.DBConnectionHelper;

public class DeleteDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection connection = null;
		PreparedStatement pStmt = null;

		int status = 0;// false
		DBConnectionHelper helper = new DBConnectionHelper();
		connection = helper.getOracleConnection();
		int rows = 0;
		String sql = "DELETE FROM PARTICIPANTS  WHERE participant_id=?";
		try {
			connection.setAutoCommit(false);
			pStmt = connection.prepareStatement(sql);
			pStmt.setString(1, "1234");
			pstmt.executeupdate();
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				System.out.println("STATEMENT SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
			}// do nothing
			try {
				if (connection != null)
					connection.close();
				System.out.println("CONNECTION SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
				se.printStackTrace();
			}// end finally try
		}// end try

		// Bind values into the parameters.
		CreateDemo.java
		System.out.println("Rows impacted : " + rows);

	}

}
