
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionHelper {
	
public static void main(String[] args){

DBConnectionHelper myCon = new DBConnectionHelper();
myCon.getOracleConnection();

}

	public Connection getOracleConnection() {
		final String url = "jdbc:oracle:thin:@01HW191082:1521:XE";
		String user = "training";
		String pwd = "training";
		Connection connection = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(url, user, pwd);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println("the connection object :: " + connection);
		return connection;
	}

}
