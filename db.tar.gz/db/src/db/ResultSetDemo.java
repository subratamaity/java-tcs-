package com;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ilp.helper.DBConnectionHelper;

public class ResultSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ResultSetDemo rsDemo = new ResultSetDemo();
		rsDemo.readRecords();
	}
	public void readRecords() {

		Connection connection = null;

		int status = 0;// false
		DBConnectionHelper helper = new DBConnectionHelper();
		connection = helper.getOracleConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			String sql = "SELECT * FROM TBL_BATCH_735379 WHERE ID "
					+ "	IN ( SELECT batch_id FROM TBL_ASSOCIATE_735379)";
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {
				// Retrieve by column name
				int id = resultSet.getInt(1);
				int sem_id = resultSet
						.getInt(2);
				String batchName = resultSet
						.getString(3);
				String sessionRoom = resultSet
				.getString(4);
				// Display values
				System.out.print("ID: " + id);
				System.out.print(", Sem: " + sem_id);
				System.out.print(", Batch: " + batchName);
				System.out.print(", Session: " + sessionRoom);
				System.out.println();

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				System.out.println("STATEMENT SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
			}// do nothing
			try {
				if (connection != null)
					connection.close();
				System.out.println("CONNECTION SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
				se.printStackTrace();
			}// end finally try
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}// end try

	}
}
