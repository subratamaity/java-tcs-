package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ilp.helper.DBConnectionHelper;

public class UpdateDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Connection connection = null;
		PreparedStatement pStmt = null;

		int status = 0;// false
		DBConnectionHelper helper = new DBConnectionHelper();
		connection = helper.getOracleConnection();
		int rows = 0;
		String sql = "UPDATE PARTICIPANTS set participant_name=? " +
				"WHERE participant_id=?";
		try {
			connection.setAutoCommit(false);
			pStmt = connection.prepareStatement(sql);
			pStmt.setString(1, "weew"); // This would set age
			pStmt.setString(2, "1234");
			pstmt.executeUpdate();
			// This would set ID

			// Let us update age of the record with ID = 102;
			
			//pStmt.addBatch();
			pStmt.executeBatch();
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null)
					pStmt.close();
				System.out.println("STATEMENT SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
			}// do nothing
			try {
				if (connection != null)
					connection.close();
				System.out.println("CONNECTION SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
				se.printStackTrace();
			}// end finally try
		}// end try

		// Bind values into the parameters.

		//System.out.println("Rows impacted : " + rows);

	}

}
