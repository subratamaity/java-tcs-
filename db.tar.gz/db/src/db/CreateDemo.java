package com.ilp.JDBCCrud;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.ilp.helper.DBConnectionHelper;

public class CreateDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


		Connection connection = null;
		/*String firstName = "ABC";
		String middleName = "XYZ";
		String lastName = "PQR";*/
		int status = 0;// false
		DBConnectionHelper helper = new DBConnectionHelper();
		connection = helper.getOracleConnection();
		Statement statement = null;
		try {
			connection.setAutoCommit(false);
			statement = connection.createStatement();
			String sql = "INSERT INTO PARTICIPANTS " +
					"VALUES ('1234','ABC','AHD04')";
			status = statement.executeUpdate(sql);
			connection.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				System.out.println("STATEMENT SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
			}// do nothing
			try {
				if (connection != null)
					connection.close();
				System.out.println("CONNECTION SUCCESSFULLY CLOSED");
			} catch (SQLException se) {
				se.printStackTrace();
			}// end finally try
		}// end try
		if (status == 1) {
			System.out.println("Data inserted successfully");
		}else{
			System.out.println("Connection error");
		}
		
	

	}

}
